<?php $__env->startSection('title', 'Please Verify Your Account'); ?>

<?php $__env->startSection('appTitle'); ?>

<div class="app-title">
    <div>
        <h1><i class="fa fa-dashboard"></i> Blank Page</h1>
        <p>Start a beautiful journey here</p>
    </div>
    <ul class="app-breadcrumb breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
        <li class="breadcrumb-item"><a href="#">Blank Page</a></li>
    </ul>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6">
        <div class="alert alert-dismissible alert-danger">
            <button class="close" type="button" data-dismiss="alert">×</button><strong>Hey <?php echo e(auth()->user()->name); ?>!</strong>Please Activate Your Account.
        </div>
    </div>
</div>
<div class="row">
    <div class="col-md-3"></div>
    <div class="col-md-6">
        <form action="<?php echo e(route('verify.mobile')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="exampleInputEmail1">Verification Code</label>
                <input class="form-control" type="text" name="code" placeholder="Verification Code">
            </div>
            <button class="btn btn-primary" type="submit">Verify</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\carryit\resources\views/unverified.blade.php ENDPATH**/ ?>