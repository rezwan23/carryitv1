<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-4">
        <div class="card">
            <h4 class="card-header"><?php echo e($post->title); ?></h4>
            <div class="card-body">
                <h4><?php echo e($post->user->name); ?> is going to <?php echo e($post->toDistrict->name); ?> from <?php echo e($post->fromDistrict->name); ?></h6>
                    <div class="post_single_body">
                        <h6 class="text-center">Details</h6>
                        <div class="row">
                            <div class="col-md-6">
                                <h6>From</h6>
                                <p>District : <?php echo e($post->fromDistrict->name); ?></p>
                                <p>Police Station : <?php echo e($post->fromPS->name); ?></p>
                            </div>
                            <div class="col-md-6">
                                <h6>To</h6>
                                <p>District : <?php echo e($post->toDistrict->name); ?></p>
                                <p>Police Station : <?php echo e($post->toPS->name); ?></p>
                            </div>
                            <div class="col-md-12 text-center call_icon" onclick="callMobile(this)">
                                <i class="fa fa-phone"></i>
                                <p class="mobile_number"><?php echo e($post->user->mobile_number); ?></p>
                            </div>
                        </div>
                    </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('head'); ?>

<style>
    .call_icon i {
        padding: 8px;
        font-size: 25px;
        background: #F86A43;
        color: #fff;
        height: 41px;
        width: 41px;
        border-radius: 50%;
    }
</style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script>
    function callMobile(el){
        let call ='tel:'+$(el).children('p.mobile_number').text();
        window.open(call);
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\carryit\resources\views/welcome.blade.php ENDPATH**/ ?>