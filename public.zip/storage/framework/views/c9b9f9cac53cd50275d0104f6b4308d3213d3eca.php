<?php $__env->startSection('title', 'Carrier Post Create'); ?>


<?php $__env->startSection('appTitle'); ?>
<div class="app-title">
    <div>
        <h1><i class="fa fa-dashboard"></i> Create Carrier Post</h1>
        <p>Start a beautiful journey here</p>
    </div>
    <!-- <ul class="app-breadcrumb breadcrumb">
        <li class="breadcrumb-item"><i class="fa fa-home fa-lg"></i></li>
        <li class="breadcrumb-item"><a href="#">Carri</a></li>
    </ul> -->
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12">
        <h4>Create Carrier Post</h4>
    </div>
    <div class="col-md-12">
        <?php echo $__env->make('layouts.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form action="<?php echo e(route('carrier-post.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="title">Title</label>
                        <input name="title" type="text" class="form-control <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                        <?php if ($errors->has('title')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('title'); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="date">Date</label>
                        <input name="date" type="date" class="form-control <?php if ($errors->has('date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>">
                        <?php if ($errors->has('date')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('date'); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h4 class="text-center">From Address</h4>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="title">District</label>
                        <select class="form-control demoSelect" name="from_district_id" id="from_district_id" onchange="loadPoliceStations(0)">
                            <optgroup label="Select Cities">
                                <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discrict): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($discrict->district_id); ?>"><?php echo e($discrict->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </optgroup>
                        </select>
                        <?php if ($errors->has('from_district_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('from_district_id'); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="date">Police Station</label>
                        <select class="form-control demoSelect" name="from_police_station_id" id="from_ps">

                        </select>
                        <?php if ($errors->has('from_police_station_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('from_police_station_id'); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="date">Post Office</label>
                        <select class="form-control demoSelect" name="from_post_office_id" id="from_po">

                        </select>
                        <?php if ($errors->has('from_police_station_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('from_police_station_id'); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="date">From Address Details</label>
                        <textarea name="from_address_details" class="form-control <?php if ($errors->has('from_address_details')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('from_address_details'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="" cols="30" rows="4"></textarea>
                        <?php if ($errors->has('from_address_details')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('from_address_details'); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <h4 class="text-center">To Address</h4>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="title">District</label>
                        <select class="form-control demoSelect" name="to_district_id" id="to_district_id" onchange="loadPoliceStations(1)">
                            <optgroup label="Select Cities">
                                <?php $__currentLoopData = $districts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $discrict): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($discrict->district_id); ?>"><?php echo e($discrict->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </optgroup>
                        </select>
                        <?php if ($errors->has('to_district_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('to_district_id'); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="date">Police Station</label>
                        <select class="form-control demoSelect" name="to_police_station_id" id="to_ps">

                        </select>
                        <?php if ($errors->has('to_police_station_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('to_police_station_id'); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="date">Post Office</label>
                        <select class="form-control demoSelect" name="to_post_office_id" id="to_po">

                        </select>
                        <?php if ($errors->has('to_post_office_id')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('to_post_office_id'); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="date">To Address Details</label>
                        <textarea name="to_address_details" class="form-control <?php if ($errors->has('to_address_details')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('to_address_details'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="" cols="30" rows="4"></textarea>
                        <?php if ($errors->has('to_address_details')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('to_address_details'); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="form-group">
                        <label for="date">Travel Description</label>
                        <textarea name="description" class="form-control <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="" cols="30" rows="4"></textarea>
                        <?php if ($errors->has('description')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('description'); ?>
                        <span class="text-danger"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                    </div>
                </div>
            </div>
            <div class="row col-md-12">
                <button class="btn btn-primary" type="submit">Post</button>
            </div>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="/admin/js/plugins/select2.min.js"></script>

<script>
    $(document).ready(function() {
        $('.demoSelect').select2();
    })

    function loadPoliceStations(isTo) {
        var id = '';
        if (isTo) {
            id = '#to_district_id';
        } else {
            id = '#from_district_id';
        }
        let districtId = $(id).val();

        if (isTo == 1) {
            $.get('/get-policestations?district_id=' + districtId, function(data) {
                $('#to_ps').empty();
                $('#to_po').empty();
                for (let i = 0; i < data[0].length; i++) {
                    $('#to_ps').append('<option value="' + data[0][i].id + '">' + data[0][i].name + '</option>');
                }
                for (let i = 0; i < data[1].length; i++) {
                    $('#to_po').append('<option value="' + data[1][i].id + '">' + data[1][i].name + '</option>');
                }
            });
        } else {
            $.get('/get-policestations?district_id=' + districtId, function(data) {
                $('#from_ps').empty();
                $('#from_po').empty();
                for (let i = 0; i < data[0].length; i++) {
                    $('#from_ps').append('<option value="' + data[0][i].id + '">' + data[0][i].name + '</option>');
                }
                for (let i = 0; i < data[1].length; i++) {
                    $('#from_po').append('<option value="' + data[1][i].id + '">' + data[1][i].name + '</option>');
                }
            });
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laragon\www\carryit\resources\views/carrier/create.blade.php ENDPATH**/ ?>